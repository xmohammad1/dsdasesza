from flask import Flask, jsonify
import os
import pymongo

app = Flask(__name__)

@app.route('/', methods=['GET'])
def main_page():
    data = '''
<!DOCTYPE html>
<html>
<head>
  <title>Welcome to BinanceScanner</title>
</head>
<body>
  <h1>Welcome to BinanceScanner!</h1>
  <ul>
    <h3>You can use these server requests:</h3>
    <li><a href="/data_ALL">Data ALL</a></li>
    <li><a href="/data_BTC">Data BTC</a></li>
    <li><a href="/data_BNB">Data BNB</a></li>
    <li><a href="/data_ETH">Data ETH</a></li>
    <li><a href="/data_USDT">Data USDT</a></li>
  </ul>
</body>
</html>
    '''
    return data

@app.route('/data_ALL', methods=['GET'])
def get_data_all():
    conn = pymongo.MongoClient('mongodb://user_reader:qasxedfv7319@ds012889.mlab.com:12889/binance_scanner')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']
    date = data['date']#.strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})

@app.route('/data_BTC', methods=['GET'])
def get_data_btc():
    conn = pymongo.MongoClient('mongodb://user_reader:qasxedfv7319@ds012889.mlab.com:12889/binance_scanner')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['BTC']
    date = data['date']#.strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})

@app.route('/data_BNB', methods=['GET'])
def get_data_bnb():
    conn = pymongo.MongoClient('mongodb://user_reader:qasxedfv7319@ds012889.mlab.com:12889/binance_scanner')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['BNB']
    date = data['date']#.strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})

@app.route('/data_ETH', methods=['GET'])
def get_data_eth():
    conn = pymongo.MongoClient('mongodb://user_reader:qasxedfv7319@ds012889.mlab.com:12889/binance_scanner')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['ETH']
    date = data['date']#.strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})

@app.route('/data_USDT', methods=['GET'])
def get_data_usdt():
    conn = pymongo.MongoClient('mongodb://user_reader:qasxedfv7319@ds012889.mlab.com:12889/binance_scanner')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['USDT']
    date = data['date']#.strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=os.environ.get('PORT', 5000))