import requests, json
import time
from datetime import datetime, timedelta
import pymongo
from multiprocessing import Pool, Process
from multiprocessing.dummy import Pool as ThreadPool
import random
import telebot as tb


# monitor bot
token = "833788522:AAHDsz17y5s48OnOjMsZ6BPpJfqQDEByAWM"
bot = tb.TeleBot(token)
dev_id = 624904668


pool = ThreadPool(8) # Количество потоков
req_lim = 1100 # Лимит запросов в минуту

# переменные-для-работы-лимита-запросов #
dt_req = (-1)
dt_req_old = (-1)
# ------------------------------------- #

conn = pymongo.MongoClient('mongodb+srv://py7hon:A1qwert@binance-scanner.zdciy.mongodb.net/binance_scanner?retryWrites=true&w=majority')
db = conn.binance_scanner
db_data = db.input_data


ticker24 = dict()

def dt_norm(dt):
    dt_obj = str(datetime.fromtimestamp(dt / 1000))  # переводим миллисекунды в datetime
    try:
        dt_obj = datetime.strptime(dt_obj, '%Y-%m-%d %H:%M:%S.%f')
    except ValueError:
        dt_obj = datetime.strptime(dt_obj, '%Y-%m-%d %H:%M:%S')
    dt_obj = dt_obj + timedelta(hours=2)
    return dt_obj


def data_request(url):
        def limit():
            global dt_req
            global dt_req_old
            global req_lim
            if dt_req != (-1):
                dt_req_old = dt_req
            while True:
                dt_req = datetime.utcnow().minute
                if dt_req == dt_req_old:
                    req_lim = req_lim - 1
                elif dt_req != dt_req_old:
                    req_lim = 1000
                if req_lim > 0:
                    break
                #print('сработал лимит')

        while True:  # Исключение ошибки с json
            limit()
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            except requests.exceptions.ConnectionError:
                continue
            except (ConnectionResetError, requests.exceptions.ChunkedEncodingError):
                bot.send_message(dev_id, '*Срочно помотреть логи!*\nПроизошла ошибка 104. Бот продолжает выполнение.', parse_mode='Markdown')
                continue
            break
        return data


def COINs(volume):
        global ticker24
        url = 'https://www.binance.com/api/v1/ticker/24hr'
        coins = list()
        data = data_request(url)
        if type(data) == list:
            for i in data:
                # print(i)
                ticker24.update({i['symbol']: i})
                if i['symbol'][-3:-1] == 'BT':
                    if i['quoteVolume'] != None:
                        if float(i['quoteVolume']) > volume:
                            close_time = dt_norm(i['closeTime'])
                            if (close_time + timedelta(minutes=15)) > datetime.now():
                                coin = i['symbol'][0:-3]
                                coins.append(coin)
        return coins


def RSIandCMOscan(coin):
        intervals = ['30m', '1h', '4h', '1d']
        results = dict()
        RSIs = dict()
        CMOs = dict()
        def RSIcalc(data, dt_int):
            # ---------------------
            obj_old = 0
            obj = 0
            plus = 0
            plus_value = 0
            minus = 0
            minus_value = 0
            # ---------------------
            k = len(data)
            x = 15  # Период + 1
            dt_per = datetime.utcnow() - timedelta(hours=float(15*dt_int))
            if k > x:
                while x > 0:
                    dt_obj = dt_norm(data[k - x][0])  # 0 = Time (в миллисекундах)
                    if dt_obj > dt_per:
                        if obj != 0:
                            obj_old = obj
                        obj = float(data[k - x][4])  # 4 = Close
                        #print(dt_obj, obj)
                        if obj_old != 0:
                            if obj > obj_old:
                                plus = plus + 1
                                plus_value = plus_value + (obj - obj_old)
                            if obj < obj_old:
                                minus = minus + 1
                                minus_value = minus_value + (obj_old - obj)
                    x = x - 1
                plus_sr = plus_value / 14
                minus_sr = minus_value / 14
                if minus_sr != 0:
                    rs = plus_sr / minus_sr
                    rsi = int(100 - 100 / (1 + rs))
                else:
                    rsi = 100
                return rsi

        def CMOcalc(data, dt_int):
            # ---------------------
            obj_old = 0
            obj = 0
            plus = 0
            plus_value = 0
            minus = 0
            minus_value = 0
            # ---------------------
            k = len(data)
            x = 15  # Период + 1
            dt_per = datetime.utcnow() - timedelta(hours=float(15*dt_int))
            if k > x:
                while x > 0:
                    dt_obj = dt_norm(data[k - x][0])  # 0 = Time (в миллисекундах)
                    if dt_obj > dt_per:
                        if obj != 0:
                            obj_old = obj
                        obj = float(data[k - x][4])  # 4 = Close
                        #print(dt_obj, obj)
                        if obj_old != 0:
                            if obj > obj_old:
                                plus = plus + 1
                                plus_value = plus_value + (obj - obj_old)
                            if obj < obj_old:
                                minus = minus + 1
                                minus_value = minus_value + (obj_old - obj)
                    x = x - 1
                cmo1 = plus_value
                cmo2 = minus_value
                try:
                    cmo = int(100 * ((cmo1 - cmo2) / (cmo1 + cmo2)))
                except:
                    cmo = 100
                return cmo

        for k in intervals:
            url = f'https://www.binance.com/api/v1/klines?symbol={coin}BTC&interval={k}'

            if k == '30m':
                dt_int = 0.5
            elif k == '1h':
                dt_int = 1
            elif k == '4h':
                dt_int = 4
            elif k == '1d':
                dt_int = 24

            data = data_request(url)
            RSI = str(RSIcalc(data, dt_int))
            CMO = str(CMOcalc(data, dt_int))
            RSIs.update({k: RSI})
            CMOs.update({k: CMO})
        results.update({'RSI': RSIs, 'CMO': CMOs})
        return results


def price_change(coin, pair):
    def pr_ch_24h(coin, pair):
        data = ticker24[f'{coin}{pair}']

        change = float(data['priceChangePercent'])
        if change > 0:
            change = '+' + '{0:.0f}'.format(change) + '%'
        else:
            change = '{0:.0f}'.format(change) + '%'
        return change
    def pr_ch_1w_1m(coin):
        url = f'https://www.binance.com/api/v1/klines?symbol={coin}BTC&interval=1h&limit=1000'
        data = data_request(url)
        dt = datetime.now()
        dt = dt.replace(minute=0, second=0, microsecond=0)
        dt_1w = dt - timedelta(days=7)
        dt_1m = dt - timedelta(days=30)
        close = float(data[len(data)-1][4])
        #print(close)
        for rec in data:
            dt_obj = dt_norm(rec[0])
            if dt_obj == dt_1w:
                close_1w = float(rec[4])
            if dt_obj == dt_1m:
                close_1m = float(rec[4])
        try:
            change_1w = close / close_1w * 100 - 100
            if change_1w > 0:
                change_1w = '+' + '{0:.2f}'.format(change_1w) + '%'
            else:
                change_1w = '{0:.2f}'.format(change_1w) + '%'
        except:
            change_1w = None
        try:
            change_1m = close / close_1m * 100 - 100
            if change_1m > 0:
                change_1m = '+' + '{0:.2f}'.format(change_1m) + '%'
            else:
                change_1m = '{0:.2f}'.format(change_1m) + '%'
        except:
            change_1m = None
        return change_1w, change_1m
    result = dict()
    try:
        change_24h = pr_ch_24h(coin, pair)
    except:
        change_24h = None
    #change_1w1m = pr_ch_1w_1m(coin)
    #change_1w = change_1w1m[0]
    #change_1m = change_1w1m[1]
    result.update({'price_change': {'24h': change_24h}})
    return result


def volume_and_change(coin, pair):
    def volume24h(coin, pair):
        try:
            data = ticker24[f'{coin}{pair}']
            bv = '{0:.0f}'.format(float(data['quoteVolume']))
        except:
            bv = None
        return bv
    def vol_ch_24(coin, pair, bv):
        def volume48(coin, pair):
            dt = datetime.now()
            hour = timedelta(hours=48)
            dt_hour = dt - hour
            url = f'https://www.binance.com/api/v1/klines?symbol={coin}{pair}&interval=5m&limit=1000'
            data = data_request(url)
            bin = data
            k = len(bin)
            x = 577
            bv48 = float()
            if k > x:
                while x > 1:
                    dt_obj = dt_norm(bin[k - x][0])  # 0 = Time (в миллисекундах)
                    bv = float(bin[k - x][7])  # 7 = BV
                    date = dt_obj.strftime('%d %b %H:%M')
                    #print(date)
                    if dt_obj > dt_hour:
                        bv48 = bv48 + bv
                    x = x - 1
            return bv48
        try:
            bv = float(bv)
            bv48 = volume48(coin, pair)
            bv_last = bv48 - bv
            bv_change = 100.0 * (bv / bv_last) - 100.0
            if bv_change > 0:
                bv_change = '+' + '{0:.0f}'.format(bv_change) + '%'
            else:
                bv_change = '{0:.0f}'.format(bv_change) + '%'
        except:
            bv_change = None

        return bv_change
    def vol_ch_w_avr(coin, pair, bv):
        def weekly_volume(coin, pair):
            dt = datetime.now().replace(minute=0, second=0, microsecond=0)
            dt_delta = dt - timedelta(days=7)
            url = f'https://www.binance.com/api/v1/klines?symbol={coin}{pair}&interval=1h&limit=1000'
            data = data_request(url)
            bin = data
            k = len(bin)
            x = 170
            bv_sum = float()
            while x > 0:
                dt_obj = dt_norm(bin[k - x][0])  # 0 = Time (в миллисекундах)
                bv = float(bin[k - x][7])  # 7 = BV
                date = dt_obj.strftime('%d %b %H:%M')
                if dt_obj >= dt_delta:
                    #print(date, bv)
                    bv_sum = bv_sum + bv
                x = x - 1
            return bv_sum
        try:
            bv = float(bv)
            bv7d = weekly_volume(coin, pair)
            bv_avr = bv7d / 7
            bv_change = bv / bv_avr * 100 - 100
            if bv_change > 0:
                bv_change = '+' + '{0:.0f}'.format(bv_change) + '%'
            else:
                bv_change = '{0:.0f}'.format(bv_change) + '%'
        except:
            bv_change = None
        return bv_change

    result = {'volume_change': {}}
    bv = volume24h(coin, pair)
    bv_change1w_avr = vol_ch_w_avr(coin, pair, bv)
    bv_change24h = vol_ch_24(coin, pair, bv)
    result.update({'volume': bv})
    result['volume_change'].update({'24h': bv_change24h, '1w_avr': bv_change1w_avr})

    return result


def get_volatility(coin, pair):
    data = ticker24[f'{coin}{pair}']
    try:
        volatility = 100.0 * (float(data['highPrice']) / float(data['lowPrice'])) - 100.0
    except:
        volatility = 0
    if volatility > 0:
        volatility = '+' + '{0:.0f}'.format(volatility) + '%'
    else:
        volatility = '{0:.0f}'.format(volatility) + '%'

    return volatility


def main(pool):
    def scan(coin):
        pair = ['BTC', 'BNB', 'ETH', 'USDT']
        for p in pair:
            if p == 'BTC':
                RSIandCMO = RSIandCMOscan(coin)
                rsi = RSIandCMO['RSI']
                cmo = RSIandCMO['CMO']
                result['BTC'].update({coin: {'rsi': rsi}})  # , 'cmo': cmo}})
            else:
                result[p].update({coin: {}})
            pr_change = price_change(coin, p)
            bv_and_bvChange = volume_and_change(coin, p)
            if (pr_change['price_change']['24h'] != None and bv_and_bvChange['volume'] != None) or p == 'BTC':
                OSC = {'osc': random.randint(0, 100)}
                volatility = {'volatility': get_volatility(coin, p)}
                result[p][coin].update(pr_change)
                result[p][coin].update(bv_and_bvChange)
                result[p][coin].update(OSC)
                result[p][coin].update(volatility)
            if result[p][coin] == {}:
                result[p].pop(coin)

    result = {'BTC': {}, 'BNB': {}, 'ETH': {}, 'USDT': {}}
    coins = COINs(0)  # 0 - минимальный объём
    pool.map(scan, coins)
    # pool.close()
    # pool.join()
    with open('result.json', 'w') as file:
        json.dump(result, file, indent=4, ensure_ascii=False)  # , sort_keys=True)
    db_data.delete_many({})
    db_data.insert_one({'result': result,
                        'date': datetime.utcnow()})
    return result


def cycle():
    bot.send_message(dev_id, 'Цикл быд запущен.')
    x = 0
    pool = ThreadPool(8)  # Количество потоков
    print('Цикл запущен!')
    while True:
        start_time = time.time()
        main(pool)
        print(int(time.time()-start_time))
        x = x + 1
        if x == 15:
            x = 0
            time.sleep(10)

if __name__ == '__main__':
    cycle()
