import requests, json

with open('result.json', 'r') as f:
    data = json.loads(f.read())
while True:
    user_input = input('Введите интервал (30m, 1h, 4h, 1d): ')
    intervals = ['30m', '1h', '4h', '1d']
    if any(user_input in s for s in intervals):
        for n in data:
            print(f"RSI {data[n]['rsi'][user_input]} | CMO {data[n]['cmo'][user_input]} | {n}")
        break
    else:
        print('Такого интервала нет')