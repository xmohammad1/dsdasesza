import requests, json
import time
from datetime import datetime, timedelta
import pymongo
from multiprocessing import Pool
from multiprocessing.dummy import Pool as ThreadPool

pool = ThreadPool(6) # Количество потоков
req_lim = 1000 # Лимит запросов в минуту

# переменные-для-работы-лимита-запросов #
dt_req = (-1)
dt_req_old = (-1)
# ------------------------------------- #

conn = pymongo.MongoClient('mongodb://py7hon:A1qwert@ds012889.mlab.com:12889/binance_scanner')
db = conn.binance_scanner
db_data = db.input_data

def data_request(url):
        def limit():
            global dt_req
            global dt_req_old
            global req_lim
            if dt_req != (-1):
                dt_req_old = dt_req
            while True:
                dt_req = datetime.utcnow().minute
                if dt_req == dt_req_old:
                    req_lim = req_lim - 1
                elif dt_req != dt_req_old:
                    req_lim = 1000
                if req_lim > 0:
                    break
                #print('сработал лимит')

        while True:  # Исключение ошибки с json
            limit()
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            except requests.exceptions.ConnectionError:
                continue
            break

        return data

def dt_norm(dt):
        dt_obj = str(datetime.fromtimestamp(dt / 1000))  # переводим миллисекунды в datetime
        try:
            dt_obj = datetime.strptime(dt_obj, '%Y-%m-%d %H:%M:%S.%f')
        except ValueError:
            dt_obj = datetime.strptime(dt_obj, '%Y-%m-%d %H:%M:%S')
        return dt_obj

def COINs(volume):
        url = 'https://www.binance.com/api/v1/ticker/24hr'
        coins = list()
        data = data_request(url)
        if type(data) == list:
            for i in data:
                # print(i)
                if i['symbol'][-3:-1] == 'BT':
                    if i['quoteVolume'] != None:
                        if float(i['quoteVolume']) > volume:
                            coin = i['symbol'][0:-3]
                            coins.append(coin)
        return coins

def RSIandCMOscan(coin):
        intervals = ['30m', '1h', '4h', '1d']
        RSIs = list()
        CMOs = list()
        results = list()
        def RSIcalc(data, dt_int):
            # ---------------------
            obj_old = 0
            obj = 0
            plus = 0
            plus_value = 0
            minus = 0
            minus_value = 0
            # ---------------------
            k = len(data)
            x = 15  # Период + 1
            dt_per = datetime.utcnow() - timedelta(hours=float(15*dt_int))
            if k > x:
                while x > 0:
                    dt_obj = dt_norm(data[k - x][0])  # 0 = Time (в миллисекундах)
                    if dt_obj > dt_per:
                        if obj != 0:
                            obj_old = obj
                        obj = float(data[k - x][4])  # 4 = Close
                        #print(dt_obj, obj)
                        if obj_old != 0:
                            if obj > obj_old:
                                plus = plus + 1
                                plus_value = plus_value + (obj - obj_old)
                            if obj < obj_old:
                                minus = minus + 1
                                minus_value = minus_value + (obj_old - obj)
                    x = x - 1
                plus_sr = plus_value / 14
                minus_sr = minus_value / 14
                if minus_sr != 0:
                    rs = plus_sr / minus_sr
                    rsi = int(100 - 100 / (1 + rs))
                else:
                    rsi = 100
                return rsi

        def CMOcalc(data, dt_int):
            # ---------------------
            obj_old = 0
            obj = 0
            plus = 0
            plus_value = 0
            minus = 0
            minus_value = 0
            # ---------------------
            k = len(data)
            x = 15  # Период + 1
            dt_per = datetime.utcnow() - timedelta(hours=float(15*dt_int))
            if k > x:
                while x > 0:
                    dt_obj = dt_norm(data[k - x][0])  # 0 = Time (в миллисекундах)
                    if dt_obj > dt_per:
                        if obj != 0:
                            obj_old = obj
                        obj = float(data[k - x][4])  # 4 = Close
                        #print(dt_obj, obj)
                        if obj_old != 0:
                            if obj > obj_old:
                                plus = plus + 1
                                plus_value = plus_value + (obj - obj_old)
                            if obj < obj_old:
                                minus = minus + 1
                                minus_value = minus_value + (obj_old - obj)
                    x = x - 1
                cmo1 = plus_value
                cmo2 = minus_value
                try:
                    cmo = int(100 * ((cmo1 - cmo2) / (cmo1 + cmo2)))
                except:
                    cmo = 100
                return cmo

        for k in intervals:
            url = f'https://www.binance.com/api/v1/klines?symbol={coin}BTC&interval={k}'

            if k == '30m':
                dt_int = 0.5
            elif k == '1h':
                dt_int = 1
            elif k == '4h':
                dt_int = 4
            elif k == '1d':
                dt_int = 24

            data = data_request(url)
            RSI = str(RSIcalc(data, dt_int))
            CMO = str(CMOcalc(data, dt_int))
            #print(RSI, CMO)
            RSIs.append(RSI)
            CMOs.append(CMO)
        results = RSIs + CMOs
        return results

def main():
        def scan(coin):
            RSIandCMO = RSIandCMOscan(coin)
            #rsi = RSIandCMO[0]
            #cmo = RSIandCMO[1]
            #print(rsi, cmo)
            res = list()
            res.append(coin)
            res = res + RSIandCMO
            result.append(res)
        result = list()
        coins = COINs(100) # 100 - минимальный объём
        #print(len(coins))
        pool.map(scan, coins)
        #pool.close()
        #pool.join()
        with open('result.json', 'w') as file:
            json.dump(result, file, indent=4, ensure_ascii=False)  # , sort_keys=True)
        db_data.delete_many({})
        db_data.insert_one({'result': result,
                            'date': datetime.utcnow()})
        return result


x = 0
while True:
    start_time = time.time()
    main()
    print(int(time.time()-start_time))
    x = x + 1
    if x == 15:
        x = 0
        time.sleep(10)
