import json, requests
from datetime import datetime, timedelta

# переменные-для-работы-лимита-запросов #
dt_req = (-1)
dt_req_old = (-1)
# ------------------------------------- #

def dt_norm(dt):
    dt_obj = str(datetime.fromtimestamp(dt / 1000))  # переводим миллисекунды в datetime
    try:
        dt_obj = datetime.strptime(dt_obj, '%Y-%m-%d %H:%M:%S.%f')
    except ValueError:
        dt_obj = datetime.strptime(dt_obj, '%Y-%m-%d %H:%M:%S')
    return dt_obj

def data_request(url):
        def limit():
            global dt_req
            global dt_req_old
            global req_lim
            if dt_req != (-1):
                dt_req_old = dt_req
            while True:
                dt_req = datetime.utcnow().minute
                if dt_req == dt_req_old:
                    req_lim = req_lim - 1
                elif dt_req != dt_req_old:
                    req_lim = 1000
                if req_lim > 0:
                    break
                #print('сработал лимит')

        while True:  # Исключение ошибки с json
            limit()
            try:
                api = requests.get(url)
                data = json.loads(api.text)
                #print(data)
            except json.decoder.JSONDecodeError:
                continue
            except requests.exceptions.ConnectionError:
                continue
            break
        return data

def COINs(volume):
        url = 'https://www.binance.com/api/v1/ticker/24hr'
        coins = list()
        data = data_request(url)
        if type(data) == list:
            for i in data:
                # print(i)
                if i['symbol'][-3:-1] == 'BT':
                    if i['quoteVolume'] != None:
                        if float(i['quoteVolume']) > volume:
                            close_time = dt_norm(i['closeTime'])
                            print(close_time, datetime.now())
                            if (close_time + timedelta(minutes=15)) > datetime.now():
                                coin = i['symbol'][0:-3]
                                coins.append(coin)
        return coins

print(COINs(0))
