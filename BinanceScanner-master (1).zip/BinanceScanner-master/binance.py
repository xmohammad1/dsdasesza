import requests, json
import time
from datetime import datetime, timedelta
from multiprocessing import Pool
from multiprocessing.dummy import Pool as ThreadPool

pool = ThreadPool(23) # Количество потоков
req_lim = 18 # Лимит запросов в секунду

# переменные-для-работы-лимита-запросов #
dt_req = (-1)
dt_req_old = (-1)
# ------------------------------------- #
def binance(coin):
    def binance_ratio(coin):
        buy = float()
        sell = float()
        url = 'https://www.binance.com/api/v1/depth?symbol=' + coin + 'BTC&limit=50'
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        q = 24
        j = 24
        # Парсим Buy
        if len(bin['bids']) > 25:
            while q > -1:
                buy = buy + float(bin['bids'][q][1])
                q = q - 1
        else:
            for k in bin['bids']:
                buy = buy + float(k[1])
        # Парсим Sell
        if len(bin['asks']) > 25:
            while j > 0:
                sell = sell + float(bin['asks'][j][1])
                j = j - 1
        else:
            for k in bin['asks']:
                sell = sell + float(k[1])
        # ----------
        sum = buy + sell
        try:
            buy = 100 * buy / sum
            sell = 100 * sell / sum
            buy = '{0:.0f}'.format(buy)
            sell = '{0:.0f}'.format(sell)
            result = f'{buy}/{sell}'
            return result
        except ZeroDivisionError:
            pass
    def binance_hourvolume(coin):
        dt = datetime.utcnow()
        hour = timedelta(hours=1, minutes=5)
        dt_hour = dt - hour
        url = 'https://www.binance.com/api/v1/klines?symbol=' + coin + 'BTC&interval=1m'
        # print(url)
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        k = len(bin)
        x = 60
        bv = float()
        if k > x:
            while x > 1:
                dt_obj = bin[k - x - 1][0]  # 0 = Time (в миллисекундах)
                dt_obj = datetime.fromtimestamp(dt_obj / 1000)  # переводим миллисекунды в datetime
                #print(dt_hour, dt_obj)
                if dt_obj > dt_hour:
                    bv = bv + float(bin[k - x - 1][7])  # 7 = BV
                x = x - 1
        return bv
    def volume48(coin):
        dt = datetime.utcnow()
        chasovoy_poyas = timedelta(hours=(+5))
        hour = timedelta(hours=48)
        dt_hour = dt - hour + chasovoy_poyas
        url = 'https://www.binance.com/api/v1/klines?symbol=' + coin + 'BTC&interval=5m&limit=1000'
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        k = len(bin)
        x = 577
        bv48 = float()
        if k > x:
            while x > 1:
                dt_obj = bin[k - x][0]  # 0 = Time (в миллисекундах)
                dt_obj = datetime.fromtimestamp(dt_obj / 1000)  # переводим миллисекунды в datetime
                bv = float(bin[k - x][7])  # 7 = BV
                date = dt_obj.strftime('%d %b %H:%M')
                # print(date)
                if dt_obj > dt_hour:
                    bv48 = bv48 + bv
                x = x - 1
        return bv48
    def volume24(coin):
        chasovoy_poyas = timedelta(hours=(+5))
        dt = datetime.utcnow()
        hour = timedelta(hours=24)
        dt_hour = dt - hour + chasovoy_poyas

        #print(dt_hour)
        url = 'https://www.binance.com/api/v1/klines?symbol=' + coin + 'BTC&interval=5m&limit=1000'
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        k = len(bin)
        x = 577
        bv24 = float()
        if k > x:
            while x > 1:
                dt_obj = bin[k - x][0]  # 0 = Time (в миллисекундах)
                dt_obj = datetime.fromtimestamp(dt_obj / 1000)  # переводим миллисекунды в datetime
                bv = float(bin[k - x][7])  # 7 = BV
                date = dt_obj.strftime('%d %b %H:%M')
                #print(date)
                if dt_obj > dt_hour:
                    bv24 = bv24 + bv
                x = x - 1
        return bv24
    url = 'https://www.binance.com/api/v1/ticker/24hr?symbol=' + coin + 'BTC'
    while True:  # Исключение ошибки с json
        try:
            api = requests.get(url)
            data = json.loads(api.text)
        except json.decoder.JSONDecodeError:
            continue
        break
    bin = data
    if type(bin) == dict:
        try:
            name = f'BTC-{coin}'
            link = f'https://www.binance.com/en/trade/{coin}_BTC'
            bid = '{0:.8f}'.format(float(bin['bidPrice']))
            ask = '{0:.8f}'.format(float(bin['askPrice']))
            bv = float(bin['quoteVolume'])
            maxprice = '{0:.8f}'.format(float(bin['highPrice']))
            minprice = '{0:.8f}'.format(float(bin['lowPrice']))
            change = float(bin['priceChangePercent'])
            if change > 0:
                change = '+' + '{0:.2f}'.format(change) + '%'
            else:
                change = '{0:.2f}'.format(change) + '%'
            volume = '{0:.2f}'.format(bv) + ' BTC'
            hourvolume = '{0:.2f}'.format(binance_hourvolume(coin)) + ' BTC'
            long_short = binance_ratio(coin)
            volatility = 100.0 * (float(bin['highPrice']) / float(bin['lowPrice'])) - 100.0
            if volatility > 0:
                volatility = '+' + '{0:.0f}'.format(volatility) + '%'
            else:
                volatility = '{0:.0f}'.format(volatility) + '%'
            bv48 = volume48(coin)
            bv_last = bv48 - bv
            bv_change = 100.0 * (bv / bv_last) - 100.0
            if bv_change > 0:
                bv_change = '+' + '{0:.2f}'.format(bv_change) + '%'
            else:
                bv_change = '{0:.2f}'.format(bv_change) + '%'
            bv24 = volume24(coin)
            msg = f'#{coin} - Binance [market]({link}) \n' \
                  f'pr.: {bid} ({change}) \n' \
                  f'min. pr.: {minprice} \n' \
                  f'max. pr.: {maxprice} ({volatility})\n' \
                  f'vol.: {hourvolume} (1h) / {volume} (24h) \n' \
                  f'vol. change: {bv_change} \n' \
                  f'long/short: {long_short}\n' \
                  f'bv24 - {bv24}\n' \
                  f'bv48 - {bv48}\n' \
                  f'bv_last - {bv48-bv24}'
            return msg
        except Exception:
            pass

x4 = 0
def binance_volume(coin):
    global x3
    dt = datetime.utcnow()
    hour = 48
    dt_hour = dt - timedelta(hours=hour)

    def volume24(coin):  # Достаём объём за 24 часа
        url = 'https://www.binance.com/api/v1/ticker/24hr?symbol=' + coin + 'BTC'
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        if type(bin) == dict:
            try:
                bid = float(bin['bidPrice'])
                bv = float(bin['quoteVolume'])
                return bv, bid
            except Exception:
                pass
    def volume48(coin):
        dt = datetime.utcnow()
        hour = timedelta(hours=48)
        dt_hour = dt - hour
        url = 'https://www.binance.com/api/v1/klines?symbol=' + coin + 'BTC&interval=5m&limit=1000'
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        k = len(bin)
        x = 577
        bv48 = float()
        if k > x:
            while x > 1:
                dt_obj = bin[k - x][0]  # 0 = Time (в миллисекундах)
                dt_obj = datetime.fromtimestamp(dt_obj / 1000)  # переводим миллисекунды в datetime
                bv = float(bin[k - x][7])  # 7 = BV
                date = dt_obj.strftime('%d %b %H:%M')
                # print(date)
                if dt_obj > dt_hour:
                    bv48 = bv48 + bv
                x = x - 1
        return bv48

    binance = volume24(coin)
    if binance != None:
        volume = binance[0]
        currentprice = binance[1]
        bv48 = volume48(coin)
        bv_last = bv48 - volume
        bv_change = 100.0 * (volume / bv_last) - 100.0
        x3 = 0
        srvol = volume / (24 * 12)
        # print(volume, srvol)
        url = 'https://www.binance.com/api/v1/klines?symbol=' + coin + 'BTC&interval=5m&limit=1000'
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        k = len(bin)
        x = (hour * 12) + 1
        xx = x
        bv2 = float()
        volprice = float()
        name = f'BTC-{coin}'
        link = f'https://www.binance.com/en/trade/{coin}_BTC'
        result = f'#{coin} - Binance [market]({link})'
        if k > x:
            while x > 1:
                dt_obj = bin[k - x][0]  # 0 = Time (в миллисекундах)
                dt_obj = datetime.fromtimestamp(dt_obj / 1000)  # переводим миллисекунды в datetime
                bv = float(bin[k - x][7])  # 7 = BV
                price = float(bin[k - x][4])  # 4 = close
                old_price = float(bin[k - x - 1][4])  # 4 = close
                change = 100.0 * (price / old_price) - 100.0
                if change > 0:
                    change = '+' + '{0:.2f}'.format(change) + '%'
                else:
                    change = '{0:.2f}'.format(change) + '%'
                date = dt_obj.strftime('%d %b %H:%M')
                #print(date)
                if dt_obj > dt_hour:
                    bv2 = bv2 + float(bin[k - x][7])  # 7 = BV
                    # print(dt_obj)
                    if bv > srvol * 6 and bv > 1 and xx != 0:
                        bv = '{0:.2f}'.format(float(bin[k - x][7]))
                        volprice = volprice + price
                        price = '{0:.8f}'.format(float(bin[k - x][4]))
                        result = result + f'\n{bv} / {price} ({change}) {date}'
                        x3 = x3 + 1
                    elif bv > srvol * 3 and bv > 0.05 and xx == 0:
                        bv = '{0:.2f}'.format(float(bin[k - x][7]))
                        volprice = volprice + price
                        price = '{0:.8f}'.format(float(bin[k - x][4]))
                        result = result + f'\n{bv} / {price} ({change}) {date}'
                        x3 = x3 + 1
                        # print(result)
                x = x - 1
                if x3 == 0 and x == 1 and xx != 0:
                    x = xx
                    xx = 0

        # print(bv2)
        if x3 == 0:
            result = result + '\nВсплесков активности не обнаружено'
        else:
            whaleprice = volprice / x3
            price_diff = 100.0 * (currentprice / whaleprice) - 100.0
            if price_diff > 0:
                price_diff = '+' + '{0:.2f}'.format(price_diff) + '%'
            else:
                price_diff = '{0:.2f}'.format(price_diff) + '%'
            price = '{0:.8f}'.format(currentprice)
            whaleprice = '{0:.8f}'.format(whaleprice)
            volume = '{0:.2f}'.format(volume)
            if bv_change > 0:
                bv_change = '+' + '{0:.2f}'.format(bv_change) + '%'
            else:
                bv_change = '{0:.2f}'.format(bv_change) + '%'
            result = result + f'\nvol.: {volume} BTC ({bv_change})' \
                              f'\nwhale pr.: {whaleprice}' \
                              f'\npr.: {price} ({price_diff})'
        return result


def binance_walls():
    def COINs(volume):
        url = 'https://www.binance.com/api/v1/ticker/24hr'
        coins = list()
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        if type(data) == list:
            for i in data:
                # print(i)
                if i['symbol'][-3:-1] == 'BT':
                    if i['quoteVolume'] != None:
                        if float(i['quoteVolume']) > volume:
                            coin = i['symbol'][0:-3]
                            coins.append(coin)
        return coins
    def binance_ratio(coin):
        global x4
        buy = float()
        sell = float()
        url = 'https://www.binance.com/api/v1/depth?symbol=' + coin + 'BTC&limit=50'
        while True:  # Исключение ошибки с json
            try:
                api = requests.get(url)
                data = json.loads(api.text)
            except json.decoder.JSONDecodeError:
                continue
            break
        bin = data
        q = 24
        j = 24
        # Парсим Buy
        if len(bin['bids']) > 25:
            while q > -1:
                buy = buy + float(bin['bids'][q][1])
                q = q - 1
        else:
            for k in bin['bids']:
                buy = buy + float(k[1])
        # Парсим Sell
        if len(bin['asks']) > 25:
            while j > 0:
                sell = sell + float(bin['asks'][j][1])
                j = j - 1
        else:
            for k in bin['asks']:
                sell = sell + float(k[1])
        # ----------
        sum = buy + sell
        try:
            buy = 100 * buy / sum
            sell = 100 * sell / sum
            if buy > 90:
                link = f'https://www.binance.com/en/trade/{coin}_BTC'
                buy = '{0:.1f}'.format(buy)
                sell = '{0:.1f}'.format(sell)
                result = f'[{coin}]({link}) --- buy: {buy}% | sell: {sell}%\n'
                x4 = x4 + 1
                return result
        except ZeroDivisionError:
            pass

    global x4
    x4 = 0
    coins = COINs(2)
    mess = str('Стенки на Binance:\n')
    def scan(coin):
        nonlocal mess
        result = binance_ratio(coin)
        if result != None:
            mess = mess + str(result)

    pool.map(scan, coins)
    pool.close()
    pool.join()

    if x4 == 0:
        mess = mess + '\n' + 'Данных нет'
    return mess

print(binance('EVX'))

print(binance_walls())

print(binance_volume('EVX'))