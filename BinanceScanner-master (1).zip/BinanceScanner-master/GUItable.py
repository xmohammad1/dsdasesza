from PyQt5.QtCore import QThread, pyqtSignal, QVariant, Qt

from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5 import QtWidgets
from qtable import *
import time
from datetime import datetime, timedelta
import sys
import pymongo

conn = pymongo.MongoClient('mongodb://user_reader:qasxedfv7319@ds012889.mlab.com:12889/binance_scanner')
db = conn.binance_scanner
db_data = db.input_data

data = db_data.find_one()
result = data['result']
date = data['date'].strftime("%d.%m.%Y %H:%M:%S")

class mywindow(QtWidgets.QMainWindow):

    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()

        self.ui.setupUi(self)

        # Кол-во рядов меняется в зависимости от значений в data.
        self.ui.tableWidget.setRowCount(
            len(result)
        )
        # Кол-во столбцов меняется в зависимости от data.
        self.ui.tableWidget.setColumnCount(
            len(result[0])
        )

        # очистка таблицы при клике на кнопку.
        self.ui.pushButton.clicked.connect(self.update)

        # заголовки для столбцов.
        self.ui.tableWidget.setHorizontalHeaderLabels(['Coin', 'RSI_30m', 'RSI_1h', 'RSI_4h', 'RSI_1d', 'CMO_30m', 'CMO_1h', 'CMO_4h', 'CMO_1d'])

        self.ui.tableWidget.setSortingEnabled(True)

        row = 0
        for tup in result:
            col = 0

            for item in tup:
                cellinfo = QTableWidgetItem()
                try:
                    cellinfo.setData(Qt.EditRole, QVariant(int(item)))
                    cellinfo.setTextAlignment(Qt.AlignCenter)
                except:
                    cellinfo.setData(Qt.EditRole, QVariant(item))
                self.ui.tableWidget.setItem(row, col, cellinfo)
                col = col + 1

            row = row + 1
        self.ui.label.setText(f"Данные обновлены {date} UTC")
        self.ui.tableWidget.resizeColumnsToContents()

    def update(self):
        data = db_data.find_one()
        result = data['result']
        date = data['date'].strftime("%d.%m.%Y %H:%M:%S")

        self.ui.tableWidget.setRowCount(len(result))

        self.ui.tableWidget.setHorizontalHeaderLabels(
            ['Coin', 'RSI_30m', 'RSI_1h', 'RSI_4h', 'RSI_1d', 'CMO_30m', 'CMO_1h', 'CMO_4h', 'CMO_1d'])
        row = 0
        for tup in result:
            col = 0

            for item in tup:
                cellinfo = QTableWidgetItem()
                try:
                    cellinfo.setData(Qt.EditRole, QVariant(int(item)))
                    cellinfo.setTextAlignment(Qt.AlignCenter)
                except:
                    cellinfo.setData(Qt.EditRole, QVariant(item))
                self.ui.tableWidget.setItem(row, col, cellinfo)
                col = col + 1

            row = row + 1

        self.ui.label.setText(f"Данные обновлены {date} UTC")
        self.ui.tableWidget.resizeColumnsToContents()

    def clear(self):
        self.ui.tableWidget.clear()


app = QtWidgets.QApplication([])
win = mywindow()
win.show()

sys.exit(app.exec())