import requests, json
import time
from datetime import datetime, timedelta
import pymongo
from multiprocessing import Pool, Process
from multiprocessing.dummy import Pool as ThreadPool
from flask import Flask, jsonify, render_template
import os
import random
from collection import cycle
from get_data import get_BTCpairs

app = Flask(__name__)

started = False
pro = 0
req_lim = 1100  # Лимит запросов в минуту

# переменные-для-работы-лимита-запросов #
dt_req = (-1)
dt_req_old = (-1)


# ------------------------------------- #

conn = pymongo.MongoClient('mongodb+srv://py7hon:A1qwert@binance-scanner.zdciy.mongodb.net/binance_scanner?retryWrites=true&w=majority')
db = conn.binance_scanner
db_data = db.input_data


@app.route('/start', methods=['GET'])
def start_collection():
    global started
    global pro
    if started == False:
        pro = Process(target=cycle)
        pro.start()
        started = True
        return 'Запуск удался!'
    else:
        return 'Процесс уже был запущен'


@app.route('/stop', methods=['GET'])
def stop_collection():
    global started
    global pro
    if started == False:
        return 'Процесс уже был остановлен'
    else:
        pro.terminate()
        started = False
        return 'Остановка процесса завершена!'


@app.route('/', methods=['GET'])
def main_page():
    pairs = get_BTCpairs()
    return render_template('table.html', title='BinanceScanner', pairs=pairs)


@app.route('/data_ALL', methods=['GET'])
def get_data_all():
    conn = pymongo.MongoClient('mongodb+srv://py7hon:A1qwert@binance-scanner.zdciy.mongodb.net/binance_scanner?retryWrites=true&w=majority')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']
    date = data['date']  # .strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})


@app.route('/data_BTC', methods=['GET'])
def get_data_btc():
    conn = pymongo.MongoClient('mongodb+srv://py7hon:A1qwert@binance-scanner.zdciy.mongodb.net/binance_scanner?retryWrites=true&w=majority')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['BTC']
    date = data['date']  # .strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})


@app.route('/data_BNB', methods=['GET'])
def get_data_bnb():
    conn = pymongo.MongoClient('mongodb+srv://py7hon:A1qwert@binance-scanner.zdciy.mongodb.net/binance_scanner?retryWrites=true&w=majority')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['BNB']
    date = data['date']  # .strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})


@app.route('/data_ETH', methods=['GET'])
def get_data_eth():
    conn = pymongo.MongoClient('mongodb+srv://py7hon:A1qwert@binance-scanner.zdciy.mongodb.net/binance_scanner?retryWrites=true&w=majority')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['ETH']
    date = data['date']  # .strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})


@app.route('/data_USDT', methods=['GET'])
def get_data_usdt():
    conn = pymongo.MongoClient('mongodb+srv://py7hon:A1qwert@binance-scanner.zdciy.mongodb.net/binance_scanner?retryWrites=true&w=majority')
    db = conn.binance_scanner
    db_data = db.input_data
    data = db_data.find_one()
    result = data['result']['USDT']
    date = data['date']  # .strftime("%d.%m.%Y %H:%M:%S")

    return jsonify({'result': result, 'date': date})


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=os.environ.get('PORT', 5000))
    # app.run(port=os.environ.get('PORT', 5000))
